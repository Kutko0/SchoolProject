<?php
    $teachers = getTeachers();
    

?>


<div class="formLine">
    <label for="ucitelVyber" style="text-align:center">Trieda :</label>
    <select name="ucitelVyber" required>
       <?php
            while ($row = mysqli_fetch_assoc($teachers)) {
                echo "<option value=" . $row["hash_id"] . ">" . $row["real_meno"] . "</option>";
            }
        ?>
      </select>
  </div>