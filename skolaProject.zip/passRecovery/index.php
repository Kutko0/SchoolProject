<?php
    include('../includes/header.php');
    include('../includes/passRecovery.php');
    include('../includes/footer.php');
?>
