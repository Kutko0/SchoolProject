<?php
    session_start();
    include('../includes/header.php');
    include('../includes/reg.php');
    include('../includes/footer.php');
?>