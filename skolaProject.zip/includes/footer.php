</div>
<footer>
  <p>Andrej Kutliak<br>
  &copy; Copyright <br>
  2018 <br>
 <a href="http://www.spsjm.sk/" target="_blank">SPSJM</a>
</p>
</footer>
</body>
</html>
