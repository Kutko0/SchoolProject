<?php
  session_start();

    include('../includes/header.php');
    include('../includes/login.php');
    include('../includes/footer.php');

?>
