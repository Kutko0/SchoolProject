<?php 
    session_start();
    include('../includes/header.php');
    include('../includes/changePass.php');
    include('../includes/footer.php');
?>